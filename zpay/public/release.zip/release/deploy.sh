#!/bin/bash
set -e

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}--- ZPAY/Z-vault-admin Automated Deployment Script ---${NC}"

# Load Docker image from tar if present
if [ -f ./zcash-wallets.tar ]; then
  echo -e "${YELLOW}Loading Docker image from ./zcash-wallets.tar...${NC}"
  docker load -i ./zcash-wallets.tar
elif [ -f ./release/zcash-wallets.tar ]; then
  echo -e "${YELLOW}Loading Docker image from ./release/zcash-wallets.tar...${NC}"
  docker load -i ./release/zcash-wallets.tar
else
  echo -e "${YELLOW}No zcash-wallets.tar found to load Docker image.${NC}"
fi

# 1. Check/Install Node.js (v16+)
if ! command -v node &> /dev/null || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 16 ]; then
  echo -e "${YELLOW}Node.js not found or too old. Installing Node.js 22 LTS...${NC}"
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y nodejs
else
  echo -e "${GREEN}Node.js found: $(node -v)${NC}"
fi

# 2. Check/Install pnpm
if ! command -v pnpm &> /dev/null; then
  echo -e "${YELLOW}pnpm not found. Installing pnpm...${NC}"
  npm install -g pnpm
else
  echo -e "${GREEN}pnpm found: $(pnpm -v)${NC}"
fi

# 3. Check/Install Docker
if ! command -v docker &> /dev/null; then
  echo -e "${YELLOW}Docker not found. Installing Docker...${NC}"
  sudo apt-get update
  sudo apt-get install -y ca-certificates curl gnupg
  sudo install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  sudo chmod a+r /etc/apt/keyrings/docker.gpg
  echo \
    "deb [arch=\"$(dpkg --print-architecture)\" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
    $(. /etc/os-release && echo \"$VERSION_CODENAME\") stable" | \
    sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  sudo apt-get update
  sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  sudo usermod -aG docker $USER
  echo -e "${YELLOW}Docker installed. You may need to log out and back in for group changes to take effect.${NC}"
else
  echo -e "${GREEN}Docker found: $(docker --version)${NC}"
fi

# 4. Check/Install PostgreSQL
if ! command -v psql &> /dev/null; then
  echo -e "${YELLOW}PostgreSQL not found. Installing PostgreSQL...${NC}"
  sudo apt-get update
  sudo apt-get install -y postgresql postgresql-contrib
else
  echo -e "${GREEN}PostgreSQL found: $(psql --version)${NC}"
fi

# Update pg_hba.conf to use md5 for local connections by postgres user
PG_HBA=$(sudo -u postgres psql -t -P format=unaligned -c "SHOW hba_file;")
sudo sed -i 's/^local\s\+all\s\+postgres\s\+peer/local all postgres md5/' "$PG_HBA"
sudo systemctl restart postgresql

# Set password for postgres user
POSTGRES_PASSWORD="postgres"
echo -e "${YELLOW}Setting password for postgres user. Change this password in production!${NC}"
sudo -u postgres psql -c "ALTER USER postgres WITH PASSWORD '$POSTGRES_PASSWORD';"

# 5. Setup PostgreSQL database and run schema
DB_NAME="ZPAY"
echo -e "${GREEN}Setting up PostgreSQL database and running schema...${NC}"
if sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname = '$DB_NAME'" | grep -q 1; then
  echo -e "${YELLOW}Database $DB_NAME already exists. Skipping creation.${NC}"
else
  sudo -u postgres createdb $DB_NAME
  echo -e "${GREEN}Database $DB_NAME created.${NC}"
fi
if [ -f ZPAY/create-db.sql ]; then
  echo -e "${GREEN}Applying database schema from ZPAY/create-db.sql...${NC}"
  sudo -u postgres psql $DB_NAME < ZPAY/create-db.sql
else
  echo -e "${YELLOW}No ZPAY/create-db.sql found. Skipping schema import.${NC}"
fi

# 6. Backend setup
# Install pm2 if not present
if ! command -v pm2 &> /dev/null; then
  echo -e "${YELLOW}pm2 not found. Installing pm2 globally...${NC}"
  npm install -g pm2
else
  echo -e "${GREEN}pm2 found: $(pm2 -v)${NC}"
fi

cd ZPAY
pnpm install --prod
pnpm add pino-pretty
if [ ! -f .env ]; then
  echo -e "${YELLOW}No .env file found in backend. Please create and configure it before starting the API.${NC}"
  BACKEND_PORT=5001
else
  echo -e "${GREEN}.env file found.${NC}"
  # Extract API_PORT from .env or use default
  BACKEND_PORT=$(grep -E '^API_PORT=' .env | cut -d'=' -f2 | tr -d '[:space:]')
  if [ -z "$BACKEND_PORT" ]; then
    BACKEND_PORT=5001
  fi
fi

echo -e "${GREEN}Starting backend API (ZPAY) on port $BACKEND_PORT using pm2...${NC}"
# Stop any existing pm2 process with the same name
pm2 delete zpay-backend || true
pm2 start dist/index.js --name zpay-backend --time
pm2 save
pm2 status

echo -e "${GREEN}Backend started with pm2. Use 'pm2 logs zpay-backend' to view logs, 'pm2 restart zpay-backend' to restart, and 'pm2 stop zpay-backend' to stop.${NC}"
echo -e "${YELLOW}Backend API is running on port $BACKEND_PORT${NC}"
cd ..

# 7. Frontend setup
echo -e "${GREEN}Setting up frontend (Z-vault-admin)...${NC}"
cd Z-vault-admin
pnpm install --prod || true
cd ..
FRONTEND_PORT=5173

# Install serve if not present
if ! command -v serve &> /dev/null; then
  echo -e "${YELLOW}serve not found. Installing serve globally...${NC}"
  npm install -g serve
else
  echo -e "${GREEN}serve found: $(serve --version)${NC}"
fi

# Start frontend with pm2
pm2 delete zvault-frontend || true
pm2 start "serve -s Z-vault-admin/dist -l tcp://0.0.0.0:$FRONTEND_PORT" --name zvault-frontend
pm2 save
pm2 status

echo -e "${GREEN}Frontend started with pm2. Use 'pm2 logs zvault-frontend' to view logs, 'pm2 restart zvault-frontend' to restart, and 'pm2 stop zvault-frontend' to stop.${NC}"
echo -e "${YELLOW}Frontend static files are being served on port $FRONTEND_PORT${NC}"
# Suggest a port for static serving (Vite default)
echo -e "${YELLOW}A common port for static serving is $FRONTEND_PORT (Vite default). Configure your web server as needed.${NC}"

echo -e "${GREEN}--- Deployment Complete! ---${NC}"
echo -e "${YELLOW}Backend API running. Frontend ready to be served. Configure your .env and web server as needed.${NC}"
